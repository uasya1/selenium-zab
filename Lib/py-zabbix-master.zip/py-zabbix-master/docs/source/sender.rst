.. _pyzabbix.sender:

======================
Module `pyzabbix.sender`
======================

.. automodule:: pyzabbix.sender
    :members:
