rocketchat.calls.groups package
===============================

Submodules
----------

rocketchat.calls.groups.get_private_room_history module
-------------------------------------------------------

.. automodule:: rocketchat.calls.groups.get_private_room_history
    :members:
    :undoc-members:
    :show-inheritance:

rocketchat.calls.groups.get_private_room_info module
----------------------------------------------------

.. automodule:: rocketchat.calls.groups.get_private_room_info
    :members:
    :undoc-members:
    :show-inheritance:

rocketchat.calls.groups.get_private_rooms module
------------------------------------------------

.. automodule:: rocketchat.calls.groups.get_private_rooms
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: rocketchat.calls.groups
    :members:
    :undoc-members:
    :show-inheritance:
