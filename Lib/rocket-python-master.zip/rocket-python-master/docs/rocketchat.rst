rocketchat package
==================

Subpackages
-----------

.. toctree::

    rocketchat.calls

Submodules
----------

rocketchat.api module
---------------------

.. automodule:: rocketchat.api
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: rocketchat
    :members:
    :undoc-members:
    :show-inheritance:
