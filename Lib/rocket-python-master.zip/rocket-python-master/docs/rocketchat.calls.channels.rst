rocketchat.calls.channels package
=================================

Submodules
----------

rocketchat.calls.channels.get_history module
--------------------------------------------

.. automodule:: rocketchat.calls.channels.get_history
    :members:
    :undoc-members:
    :show-inheritance:

rocketchat.calls.channels.get_public_rooms module
-------------------------------------------------

.. automodule:: rocketchat.calls.channels.get_public_rooms
    :members:
    :undoc-members:
    :show-inheritance:

rocketchat.calls.channels.get_room_info module
----------------------------------------------

.. automodule:: rocketchat.calls.channels.get_room_info
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: rocketchat.calls.channels
    :members:
    :undoc-members:
    :show-inheritance:
