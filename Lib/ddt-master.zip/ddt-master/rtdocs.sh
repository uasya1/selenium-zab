curl --data '' http://readthedocs.org/build/ddt
